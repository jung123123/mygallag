package com.taewon.mygallag;


public class PauseDialog {

}
