package com.taewon.mygallag.sprites;



public class ShotSprite{
}
